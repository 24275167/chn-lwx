const { createConnection } = require('mysql2');
// mysql连接
const mysql = createConnection({
  host: 'localhost',
  user: 'wli100_root',
  password: 'crowdfunding_db',
  database: 'wli100_crowdfunding_db',
}).promise();
module.exports = mysql
